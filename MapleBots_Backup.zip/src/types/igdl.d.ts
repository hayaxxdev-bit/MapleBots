declare module '@sasmeee/igdl';
